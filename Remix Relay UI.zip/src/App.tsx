import { useState, type ReactNode } from "react"
// ... other imports

type IconName = "home" | "projects" | "tasks" | "team" | "settings" | "search" | "plus" | "bell" | "arrow" | "menu" | "close" | "play"

const paths: Record<IconName, ReactNode> = {
  home: (
    <>
      <path d="m3 10 9-7 9 7" />
      <path d="M5 9v11h14V9M9 20v-7h6v7" />
    </>
  ),
  projects: (
    <>
      <rect x="3" y="4" width="18" height="16" rx="2" />
      <path d="M3 9h18M8 4v5" />
    </>
  ),
  tasks: (
    <>
      <path d="M9 5h11M9 12h11M9 19h11" />
      <path d="m3 5 1 1 2-2m-3 8 1 1 2-2m-3 8 1 1 2-2" />
    </>
  ),
  team: (
    <>
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06a1.7 1.7 0 0 0-1.88-.34 1.7 1.7 0 0 0-1.03 1.56V21h-4v-.09A1.7 1.7 0 0 0 9 19.36a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.63 15 1.7 1.7 0 0 0 3.09 14H3v-4h.09A1.7 1.7 0 0 0 4.64 9a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 9 4.63h.01A1.7 1.7 0 0 0 10 3.09V3h4v.09A1.7 1.7 0 0 0 15 4.64a1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.37 9v.01A1.7 1.7 0 0 0 20.91 10H21v4h-.09A1.7 1.7 0 0 0 19.4 15Z" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-4-4" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  bell: (
    <>
      <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" />
    </>
  ),
  arrow: (
    <>
      <path d="M5 12h14M13 6l6 6-6 6" />
    </>
  ),
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  close: <path d="m6 6 12 12M18 6 6 18" />,
  play: <path d="m9 7 8 5-8 5V7Z" />,
}

function Icon({
  name,
  className = "size-5",
}: {
  name: IconName
  className?: string
}) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  )
}

const nav = [
  ["Overview", "home"],
  ["Projects", "projects"],
  ["Tasks", "tasks"],
  ["Team", "team"],
] as const

const projects = [
  {
    name: "Song 1",
    color: "#5f5af6",
    edited: "Last edited 12 minutes ago",
  },
  {
    name: "Song 2",
    color: "#e6a23c",
    edited: "Last edited 1 hour ago",
  },
  {
    name: "Song 3",
    color: "#2b9a72",
    edited: "Last edited 3 hours ago",
  },
  {
    name: "Song 4",
    color: "#e16863",
    edited: "Last edited yesterday",
  },
]

export default function App() {
  const [active, setActive] = useState("Overview")
  const [menuOpen, setMenuOpen] = useState(false)
  const [notice, setNotice] = useState(false)
  const [selectedSong, setSelectedSong] = useState<string | null>(null)

  if (selectedSong === "Song 1") {
    return (
      <div className="min-h-screen bg-[#f7f7f5] text-[#1c1c1b]">
        <header className="flex h-[76px] items-center justify-between border-b border-[#e8e8e4] bg-white px-5 md:px-9">
          <button
            onClick={() => setSelectedSong(null)}
            className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-[#696964] transition hover:bg-[#f1f1ee] hover:text-[#222]"
          >
            <Icon name="arrow" className="size-4 rotate-180" />
            Back to projects
          </button>
          <div className="flex items-center gap-3">
            <span className="hidden text-xs text-[#8b8b85] sm:block">
              Saved just now
            </span>
            <button className="rounded-xl bg-[#5f5af6] px-4 py-2.5 text-sm font-medium text-white transition hover:bg-[#4f4ae2]">
              Share project
            </button>
          </div>
        </header>

        <main className="mx-auto max-w-[1120px] p-5 md:p-10">
          <div className="mb-8 flex flex-wrap items-start justify-between gap-5">
            <div className="flex items-center gap-4">
              <span className="grid size-14 place-items-center rounded-2xl bg-[#5f5af6] text-lg font-semibold text-white">
                S
              </span>
              <div>
                <p className="mb-1 text-xs font-medium uppercase tracking-[0.14em] text-[#8b8b85]">
                  Music project
                </p>
                <h1 className="text-3xl font-semibold tracking-[-0.04em]">
                  Song 1
                </h1>
              </div>
            </div>
            <div className="flex -space-x-2">
              {["DA", "AV", "VK"].map((initials, index) => (
                <span
                  key={initials}
                  className={`grid size-9 place-items-center rounded-full border-2 border-[#f7f7f5] text-[10px] font-semibold ${
                    [
                      "bg-[#d9e8ff] text-[#285080]",
                      "bg-[#e0f1ea] text-[#39725f]",
                      "bg-[#fdeadd] text-[#995c36]",
                    ][index]
                  }`}
                >
                  {initials}
                </span>
              ))}
            </div>
          </div>

          <div className="grid gap-5 lg:grid-cols-[1.6fr_0.8fr]">
            <section className="card p-5 md:p-7">
              <div className="mb-8 flex items-center justify-between">
                <div>
                  <h2 className="font-semibold tracking-[-0.02em]">
                    Latest mix
                  </h2>
                  <p className="mt-1 text-xs text-[#888883]">
                    Version 04 · Edited 12 minutes ago
                  </p>
                </div>
                <button
                  className="grid size-11 place-items-center rounded-full bg-[#282827] text-white transition hover:scale-105"
                  aria-label="Play latest mix"
                >
                  <Icon name="play" className="ml-0.5 size-5" />
                </button>
              </div>
              <div className="flex h-36 items-center gap-1 overflow-hidden rounded-2xl bg-[#f4f3ff] px-5">
                {[
                  24, 42, 68, 38, 76, 92, 58, 34, 72, 48, 88, 64, 30, 52, 82,
                  44, 68, 96, 54, 38, 78, 62, 46, 86, 56, 34, 72, 48, 90, 60,
                  40, 74, 52, 84, 36, 66,
                ].map((height, index) => (
                  <span
                    key={index}
                    className="min-w-1 flex-1 rounded-full bg-[#7772f7]"
                    style={{
                      height: `${height}%`,
                      opacity: 0.45 + (index % 4) * 0.14,
                    }}
                  />
                ))}
              </div>
              <div className="mt-3 flex justify-between text-[11px] text-[#999993]">
                <span>0:00</span>
                <span>3:42</span>
              </div>

              <div className="mt-8">
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="text-sm font-semibold">Project files</h3>
                  <button className="text-xs font-medium text-[#5f5af6]">
                    Add file
                  </button>
                </div>
                {[
                  ["Lead vocals.wav", "42.8 MB"],
                  ["Instrumental v4.wav", "68.2 MB"],
                  ["Song notes.txt", "4 KB"],
                ].map(([file, size]) => (
                  <button
                    key={file}
                    className="flex w-full items-center justify-between border-t border-[#eeeeea] py-3 text-left"
                  >
                    <span className="text-sm font-medium">{file}</span>
                    <span className="text-xs text-[#92928c]">{size}</span>
                  </button>
                ))}
              </div>
            </section>

            <aside className="space-y-5">
              <section className="card p-5">
                <h2 className="mb-4 font-semibold tracking-[-0.02em]">
                  Project details
                </h2>
                <dl className="space-y-4 text-sm">
                  <div>
                    <dt className="text-xs text-[#92928c]">Status</dt>
                    <dd className="mt-1 font-medium text-[#2b8c68]">
                      In progress
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-[#92928c]">Collaborators</dt>
                    <dd className="mt-1 font-medium">
                      David, Ashley, Victoria
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-[#92928c]">Created</dt>
                    <dd className="mt-1 font-medium">May 08, 2025</dd>
                  </div>
                </dl>
              </section>
              <section className="card p-5">
                <h2 className="font-semibold tracking-[-0.02em]">Notes</h2>
                <p className="mt-3 text-sm leading-6 text-[#73736e]">
                  Refine the second verse and review the final vocal take before
                  the next mix.
                </p>
                <button className="mt-4 text-xs font-medium text-[#5f5af6]">
                  Edit notes
                </button>
              </section>
            </aside>
          </div>
        </main>
      </div>
    )
  }

  if (selectedSong === "Song 2") {
    return (
      <div className="min-h-screen bg-[#f7f7f5] text-[#1c1c1b]">
        <header className="flex h-[76px] items-center justify-between border-b border-[#e8e8e4] bg-white px-5 md:px-9">
          <button
            onClick={() => setSelectedSong(null)}
            className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-[#696964] transition hover:bg-[#f1f1ee] hover:text-[#222]"
          >
            <Icon name="arrow" className="size-4 rotate-180" />
            Back to projects
          </button>
          <div className="flex items-center gap-3">
            <span className="hidden text-xs text-[#8b8b85] sm:block">
              Saved just now
            </span>
            <button className="rounded-xl bg-[#5f5af6] px-4 py-2.5 text-sm font-medium text-white transition hover:bg-[#4f4ae2]">
              Share project
            </button>
          </div>
        </header>

        <main className="mx-auto max-w-[1120px] p-5 md:p-10">
          <div className="mb-8 flex flex-wrap items-start justify-between gap-5">
            <div className="flex items-center gap-4">
              <span className="grid size-14 place-items-center rounded-2xl bg-[#e6a23c] text-lg font-semibold text-white">
                S
              </span>
              <div>
                <p className="mb-1 text-xs font-medium uppercase tracking-[0.14em] text-[#8b8b85]">
                  Music project
                </p>
                <h1 className="text-3xl font-semibold tracking-[-0.04em]">
                  Song 2
                </h1>
              </div>
            </div>
            <div className="flex -space-x-2">
              {["DA", "AV", "VK"].map((initials, index) => (
                <span
                  key={initials}
                  className={`grid size-9 place-items-center rounded-full border-2 border-[#f7f7f5] text-[10px] font-semibold ${
                    [
                      "bg-[#d9e8ff] text-[#285080]",
                      "bg-[#e0f1ea] text-[#39725f]",
                      "bg-[#fdeadd] text-[#995c36]",
                    ][index]
                  }`}
                >
                  {initials}
                </span>
              ))}
            </div>
          </div>

          <div className="grid gap-5 lg:grid-cols-[1.6fr_0.8fr]">
            <section className="card p-5 md:p-7">
              <div className="mb-8 flex items-center justify-between">
                <div>
                  <h2 className="font-semibold tracking-[-0.02em]">
                    Latest mix
                  </h2>
                  <p className="mt-1 text-xs text-[#888883]">
                    Version 04 · Edited 12 minutes ago
                  </p>
                </div>
                <button
                  className="grid size-11 place-items-center rounded-full bg-[#282827] text-white transition hover:scale-105"
                  aria-label="Play latest mix"
                >
                  <Icon name="play" className="ml-0.5 size-5" />
                </button>
              </div>
              <div className="flex h-36 items-center gap-1 overflow-hidden rounded-2xl bg-[#f4f3ff] px-5">
                {[
                  24, 42, 68, 38, 76, 92, 58, 34, 72, 48, 88, 64, 30, 52, 82,
                  44, 68, 96, 54, 38, 78, 62, 46, 86, 56, 34, 72, 48, 90, 60,
                  40, 74, 52, 84, 36, 66,
                ].map((height, index) => (
                  <span
                    key={index}
                    className="min-w-1 flex-1 rounded-full bg-[#7772f7]"
                    style={{
                      height: `${height}%`,
                      opacity: 0.45 + (index % 4) * 0.14,
                    }}
                  />
                ))}
              </div>
              <div className="mt-3 flex justify-between text-[11px] text-[#999993]">
                <span>0:00</span>
                <span>3:42</span>
              </div>

              <div className="mt-8">
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="text-sm font-semibold">Project files</h3>
                  <button className="text-xs font-medium text-[#5f5af6]">
                    Add file
                  </button>
                </div>
                {[
                  ["Lead vocals.wav", "42.8 MB"],
                  ["Instrumental v4.wav", "68.2 MB"],
                  ["Song notes.txt", "4 KB"],
                ].map(([file, size]) => (
                  <button
                    key={file}
                    className="flex w-full items-center justify-between border-t border-[#eeeeea] py-3 text-left"
                  >
                    <span className="text-sm font-medium">{file}</span>
                    <span className="text-xs text-[#92928c]">{size}</span>
                  </button>
                ))}
              </div>
            </section>

            <aside className="space-y-5">
              <section className="card p-5">
                <h2 className="mb-4 font-semibold tracking-[-0.02em]">
                  Project details
                </h2>
                <dl className="space-y-4 text-sm">
                  <div>
                    <dt className="text-xs text-[#92928c]">Status</dt>
                    <dd className="mt-1 font-medium text-[#2b8c68]">
                      In progress
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-[#92928c]">Collaborators</dt>
                    <dd className="mt-1 font-medium">
                      David, Ashley, Victoria
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-[#92928c]">Created</dt>
                    <dd className="mt-1 font-medium">May 08, 2025</dd>
                  </div>
                </dl>
              </section>
              <section className="card p-5">
                <h2 className="font-semibold tracking-[-0.02em]">Notes</h2>
                <p className="mt-3 text-sm leading-6 text-[#73736e]">
                  Refine the second verse and review the final vocal take before
                  the next mix.
                </p>
                <button className="mt-4 text-xs font-medium text-[#5f5af6]">
                  Edit notes
                </button>
              </section>
            </aside>
          </div>
        </main>
      </div>
    )
  }

  if (selectedSong === "Song 3") {
    return (
      <div className="min-h-screen bg-[#f7f7f5] text-[#1c1c1b]">
        <header className="flex h-[76px] items-center justify-between border-b border-[#e8e8e4] bg-white px-5 md:px-9">
          <button
            onClick={() => setSelectedSong(null)}
            className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-[#696964] transition hover:bg-[#f1f1ee] hover:text-[#222]"
          >
            <Icon name="arrow" className="size-4 rotate-180" />
            Back to projects
          </button>
          <div className="flex items-center gap-3">
            <span className="hidden text-xs text-[#8b8b85] sm:block">
              Saved just now
            </span>
            <button className="rounded-xl bg-[#5f5af6] px-4 py-2.5 text-sm font-medium text-white transition hover:bg-[#4f4ae2]">
              Share project
            </button>
          </div>
        </header>

        <main className="mx-auto max-w-[1120px] p-5 md:p-10">
          <div className="mb-8 flex flex-wrap items-start justify-between gap-5">
            <div className="flex items-center gap-4">
              <span className="grid size-14 place-items-center rounded-2xl bg-[#2b9a72] text-lg font-semibold text-white">
                S
              </span>
              <div>
                <p className="mb-1 text-xs font-medium uppercase tracking-[0.14em] text-[#8b8b85]">
                  Music project
                </p>
                <h1 className="text-3xl font-semibold tracking-[-0.04em]">
                  Song 3
                </h1>
              </div>
            </div>
            <div className="flex -space-x-2">
              {["DA", "AV", "VK"].map((initials, index) => (
                <span
                  key={initials}
                  className={`grid size-9 place-items-center rounded-full border-2 border-[#f7f7f5] text-[10px] font-semibold ${
                    [
                      "bg-[#d9e8ff] text-[#285080]",
                      "bg-[#e0f1ea] text-[#39725f]",
                      "bg-[#fdeadd] text-[#995c36]",
                    ][index]
                  }`}
                >
                  {initials}
                </span>
              ))}
            </div>
          </div>

          <div className="grid gap-5 lg:grid-cols-[1.6fr_0.8fr]">
            <section className="card p-5 md:p-7">
              <div className="mb-8 flex items-center justify-between">
                <div>
                  <h2 className="font-semibold tracking-[-0.02em]">
                    Latest mix
                  </h2>
                  <p className="mt-1 text-xs text-[#888883]">
                    Version 04 · Edited 12 minutes ago
                  </p>
                </div>
                <button
                  className="grid size-11 place-items-center rounded-full bg-[#282827] text-white transition hover:scale-105"
                  aria-label="Play latest mix"
                >
                  <Icon name="play" className="ml-0.5 size-5" />
                </button>
              </div>
              <div className="flex h-36 items-center gap-1 overflow-hidden rounded-2xl bg-[#f4f3ff] px-5">
                {[
                  24, 42, 68, 38, 76, 92, 58, 34, 72, 48, 88, 64, 30, 52, 82,
                  44, 68, 96, 54, 38, 78, 62, 46, 86, 56, 34, 72, 48, 90, 60,
                  40, 74, 52, 84, 36, 66,
                ].map((height, index) => (
                  <span
                    key={index}
                    className="min-w-1 flex-1 rounded-full bg-[#7772f7]"
                    style={{
                      height: `${height}%`,
                      opacity: 0.45 + (index % 4) * 0.14,
                    }}
                  />
                ))}
              </div>
              <div className="mt-3 flex justify-between text-[11px] text-[#999993]">
                <span>0:00</span>
                <span>3:42</span>
              </div>

              <div className="mt-8">
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="text-sm font-semibold">Project files</h3>
                  <button className="text-xs font-medium text-[#5f5af6]">
                    Add file
                  </button>
                </div>
                {[
                  ["Lead vocals.wav", "42.8 MB"],
                  ["Instrumental v4.wav", "68.2 MB"],
                  ["Song notes.txt", "4 KB"],
                ].map(([file, size]) => (
                  <button
                    key={file}
                    className="flex w-full items-center justify-between border-t border-[#eeeeea] py-3 text-left"
                  >
                    <span className="text-sm font-medium">{file}</span>
                    <span className="text-xs text-[#92928c]">{size}</span>
                  </button>
                ))}
              </div>
            </section>

            <aside className="space-y-5">
              <section className="card p-5">
                <h2 className="mb-4 font-semibold tracking-[-0.02em]">
                  Project details
                </h2>
                <dl className="space-y-4 text-sm">
                  <div>
                    <dt className="text-xs text-[#92928c]">Status</dt>
                    <dd className="mt-1 font-medium text-[#2b8c68]">
                      In progress
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-[#92928c]">Collaborators</dt>
                    <dd className="mt-1 font-medium">
                      David, Ashley, Victoria
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-[#92928c]">Created</dt>
                    <dd className="mt-1 font-medium">May 08, 2025</dd>
                  </div>
                </dl>
              </section>
              <section className="card p-5">
                <h2 className="font-semibold tracking-[-0.02em]">Notes</h2>
                <p className="mt-3 text-sm leading-6 text-[#73736e]">
                  Refine the second verse and review the final vocal take before
                  the next mix.
                </p>
                <button className="mt-4 text-xs font-medium text-[#5f5af6]">
                  Edit notes
                </button>
              </section>
            </aside>
          </div>
        </main>
      </div>
    )
  }

  if (selectedSong === "Song 4") {
    return (
      <div className="min-h-screen bg-[#f7f7f5] text-[#1c1c1b]">
        <header className="flex h-[76px] items-center justify-between border-b border-[#e8e8e4] bg-white px-5 md:px-9">
          <button
            onClick={() => setSelectedSong(null)}
            className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-[#696964] transition hover:bg-[#f1f1ee] hover:text-[#222]"
          >
            <Icon name="arrow" className="size-4 rotate-180" />
            Back to projects
          </button>
          <div className="flex items-center gap-3">
            <span className="hidden text-xs text-[#8b8b85] sm:block">
              Saved just now
            </span>
            <button className="rounded-xl bg-[#5f5af6] px-4 py-2.5 text-sm font-medium text-white transition hover:bg-[#4f4ae2]">
              Share project
            </button>
          </div>
        </header>

        <main className="mx-auto max-w-[1120px] p-5 md:p-10">
          <div className="mb-8 flex flex-wrap items-start justify-between gap-5">
            <div className="flex items-center gap-4">
              <span className="grid size-14 place-items-center rounded-2xl bg-[#5f5af6] text-lg font-semibold text-white">
                S
              </span>
              <div>
                <p className="mb-1 text-xs font-medium uppercase tracking-[0.14em] text-[#8b8b85]">
                  Music project
                </p>
                <h1 className="text-3xl font-semibold tracking-[-0.04em]">
                  Song 4
                </h1>
              </div>
            </div>
            <div className="flex -space-x-2">
              {["DA", "AV", "VK"].map((initials, index) => (
                <span
                  key={initials}
                  className={`grid size-9 place-items-center rounded-full border-2 border-[#f7f7f5] text-[10px] font-semibold ${
                    [
                      "bg-[#d9e8ff] text-[#285080]",
                      "bg-[#e0f1ea] text-[#39725f]",
                      "bg-[#fdeadd] text-[#995c36]",
                    ][index]
                  }`}
                >
                  {initials}
                </span>
              ))}
            </div>
          </div>

          <div className="grid gap-5 lg:grid-cols-[1.6fr_0.8fr]">
            <section className="card p-5 md:p-7">
              <div className="mb-8 flex items-center justify-between">
                <div>
                  <h2 className="font-semibold tracking-[-0.02em]">
                    Latest mix
                  </h2>
                  <p className="mt-1 text-xs text-[#888883]">
                    Version 04 · Edited 12 minutes ago
                  </p>
                </div>
                <button
                  className="grid size-11 place-items-center rounded-full bg-[#282827] text-white transition hover:scale-105"
                  aria-label="Play latest mix"
                >
                  <Icon name="play" className="ml-0.5 size-5" />
                </button>
              </div>
              <div className="flex h-36 items-center gap-1 overflow-hidden rounded-2xl bg-[#f4f3ff] px-5">
                {[
                  24, 42, 68, 38, 76, 92, 58, 34, 72, 48, 88, 64, 30, 52, 82,
                  44, 68, 96, 54, 38, 78, 62, 46, 86, 56, 34, 72, 48, 90, 60,
                  40, 74, 52, 84, 36, 66,
                ].map((height, index) => (
                  <span
                    key={index}
                    className="min-w-1 flex-1 rounded-full bg-[#7772f7]"
                    style={{
                      height: `${height}%`,
                      opacity: 0.45 + (index % 4) * 0.14,
                    }}
                  />
                ))}
              </div>
              <div className="mt-3 flex justify-between text-[11px] text-[#999993]">
                <span>0:00</span>
                <span>3:42</span>
              </div>

              <div className="mt-8">
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="text-sm font-semibold">Project files</h3>
                  <button className="text-xs font-medium text-[#5f5af6]">
                    Add file
                  </button>
                </div>
                {[
                  ["Lead vocals.wav", "42.8 MB"],
                  ["Instrumental v4.wav", "68.2 MB"],
                  ["Song notes.txt", "4 KB"],
                ].map(([file, size]) => (
                  <button
                    key={file}
                    className="flex w-full items-center justify-between border-t border-[#eeeeea] py-3 text-left"
                  >
                    <span className="text-sm font-medium">{file}</span>
                    <span className="text-xs text-[#92928c]">{size}</span>
                  </button>
                ))}
              </div>
            </section>

            <aside className="space-y-5">
              <section className="card p-5">
                <h2 className="mb-4 font-semibold tracking-[-0.02em]">
                  Project details
                </h2>
                <dl className="space-y-4 text-sm">
                  <div>
                    <dt className="text-xs text-[#92928c]">Status</dt>
                    <dd className="mt-1 font-medium text-[#2b8c68]">
                      In progress
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-[#92928c]">Collaborators</dt>
                    <dd className="mt-1 font-medium">
                      David, Ashley, Victoria
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-[#92928c]">Created</dt>
                    <dd className="mt-1 font-medium">May 08, 2025</dd>
                  </div>
                </dl>
              </section>
              <section className="card p-5">
                <h2 className="font-semibold tracking-[-0.02em]">Notes</h2>
                <p className="mt-3 text-sm leading-6 text-[#73736e]">
                  Refine the second verse and review the final vocal take before
                  the next mix.
                </p>
                <button className="mt-4 text-xs font-medium text-[#5f5af6]">
                  Edit notes
                </button>
              </section>
            </aside>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#f7f7f5] text-[#1c1c1b]">
      {menuOpen && (
        <button
          aria-label="Close menu"
          className="fixed inset-0 z-30 bg-black/20 md:hidden"
          onClick={() => setMenuOpen(false)}
        />
      )}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-[248px] flex-col border-r border-[#e8e8e4] bg-[#fbfbfa] p-5 transition-transform md:translate-x-0 ${
          menuOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="mb-10 flex items-center justify-between px-2">
          <div className="flex items-center gap-3">
            <div className="grid size-9 place-items-center rounded-xl bg-[#282827] text-sm font-semibold text-white">
              N
            </div>
            <span className="text-[17px] font-semibold tracking-[-0.03em]">
              Northstar
            </span>
          </div>
          <button
            className="icon-button md:hidden"
            onClick={() => setMenuOpen(false)}
            aria-label="Close menu"
          >
            <Icon name="close" />
          </button>
        </div>

        <nav className="space-y-1" aria-label="Main navigation">
          {nav.map(([label, icon]) => (
            <button
              key={label}
              onClick={() => {
                setActive(label)
                setMenuOpen(false)
              }}
              className={`nav-item ${
                active === label ? "nav-item-active" : ""
              }`}
            >
              <Icon name={icon} />
              {label}
            </button>
          ))}
        </nav>

        <div className="mt-auto">
          <button
            onClick={() => setActive("Settings")}
            className={`nav-item mb-5 ${
              active === "Settings" ? "nav-item-active" : ""
            }`}
          >
            <Icon name="settings" />
            Settings
          </button>
          <div className="rounded-2xl border border-[#e5e5e1] bg-white p-3">
            <div className="flex items-center gap-3">
              <div className="grid size-9 shrink-0 place-items-center rounded-full bg-[#d9e8ff] text-xs font-semibold text-[#285080]">
                AM
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">Alex Morgan</p>
                <p className="truncate text-xs text-[#858580]">
                  alex@example.com
                </p>
              </div>
              <button className="text-[#8a8a85]" aria-label="Account menu">
                •••
              </button>
            </div>
          </div>
        </div>
      </aside>

      <main className="min-h-screen md:ml-[248px]">
        <header className="flex h-[76px] items-center gap-4 border-b border-[#e8e8e4] bg-[#f7f7f5]/90 px-5 backdrop-blur md:px-9">
          <button
            className="icon-button md:hidden"
            onClick={() => setMenuOpen(true)}
            aria-label="Open menu"
          >
            <Icon name="menu" />
          </button>
          <label className="relative hidden max-w-[360px] flex-1 sm:block">
            <Icon
              name="search"
              className="absolute left-3 top-1/2 size-[18px] -translate-y-1/2 text-[#999993]"
            />
            <input
              className="h-10 w-full rounded-xl border border-[#e3e3df] bg-white pl-10 pr-3 text-sm outline-none transition focus:border-[#aaa9ff] focus:ring-2 focus:ring-[#5f5af6]/10"
              placeholder="Search anything..."
            />
          </label>
          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={() => setNotice(!notice)}
              className="icon-button relative"
              aria-label="Notifications"
            >
              <Icon name="bell" />
              <span className="absolute right-2 top-2 size-1.5 rounded-full bg-[#ef675f] ring-2 ring-white" />
            </button>
            <button
              onClick={() => setNotice(false)}
              className="ml-1 flex items-center gap-2 rounded-xl bg-[#5f5af6] px-4 py-2.5 text-sm font-medium text-white shadow-sm transition hover:bg-[#4f4ae2] active:scale-[.98]"
            >
              <Icon name="plus" className="size-4" /> New project
            </button>
          </div>
          {notice && (
            <div className="absolute right-36 top-16 z-20 w-64 rounded-xl border border-[#e5e5e1] bg-white p-4 text-sm shadow-xl">
              <p className="font-medium">You’re all caught up</p>
              <p className="mt-1 text-[#777772]">No new notifications.</p>
            </div>
          )}
        </header>

        <div className="mx-auto max-w-[1320px] p-5 md:p-9">
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="mb-1 text-sm text-[#767671]">Tuesday, May 14</p>
              <h1 className="text-3xl font-semibold tracking-[-0.04em]">
                Good morning, Alex
              </h1>
            </div>
            <p className="max-w-sm text-sm leading-6 text-[#777772]">
              Here’s what’s happening across your workspace today.
            </p>
          </div>

          <section className="mt-5">
            <div className="card overflow-hidden">
              <div className="flex items-center justify-between border-b border-[#ecece8] px-5 py-5">
                <div>
                  <h2 className="font-semibold tracking-[-0.02em]">
                    Recent projects
                  </h2>
                  <p className="mt-1 text-xs text-[#888883]">
                    Your team’s latest work
                  </p>
                </div>
                <button className="flex items-center gap-2 text-sm font-medium text-[#5f5af6]">
                  View all <Icon name="arrow" className="size-4" />
                </button>
              </div>
              <div className="grid grid-cols-1 gap-4 p-5 sm:grid-cols-2">
                {projects.map((project) => (
                  <button
                    key={project.name}
                    onClick={() => setSelectedSong(project.name)}
                    className="flex min-h-[96px] w-full items-center gap-4 rounded-xl border border-[#e8e8e4] px-5 py-4 text-left transition hover:border-[#d8d8d2] hover:bg-[#fafaf8]"
                  >
                    <span
                      className="grid size-11 shrink-0 place-items-center rounded-xl text-sm font-semibold text-white"
                      style={{ background: project.color }}
                    >
                      {project.name[0]}
                    </span>
                    <div>
                      <p className="text-sm font-medium">{project.name}</p>
                      <p className="mt-1 text-xs text-[#8b8b85]">
                        {project.edited}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}
